package exam;

public class IsLegalNumber {
	public static int isLegalNumber(int[] a, int base) {
		
		if(base < 2) {
			return 0;
		}
		
		int result = 1;
		
		for (int i : a) {
			if(i >= base) {
				result = 0;
				break;
			}
		}
		
		return result;
	}
}
