package exam;

public class IsStacked {
	public static int isStacked(int n) {
		return IsTriangular.isTriangular(n);
	}
}
