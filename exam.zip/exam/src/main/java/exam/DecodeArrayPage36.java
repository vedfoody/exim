package exam;

public class DecodeArrayPage36 {

	public static int decodeArray(int[] a) {
		int result = 0;
		int d;
		
		if(a.length < 2) {
			throw new RuntimeException("the array has at least two elements.");
		}
		
		for(int i = 0; i<a.length - 1; i++) {
			d = diff(a[i], a[i+1]);
			if(d < 10) {
				result = result*10 + d;
			} else {
				throw new RuntimeException(String.format("The absolute value of the difference of any two elements [%d vs %d] is not between 0 and 9.", i, i+1));
			}
		}
		
		return a[0] < 0 ? -result : result;
	}

	private static int diff(int a, int b) {
		return a<b ? b-a : a-b;
	}
}
