package exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClosestFibonacci {

private static List<Integer> cache = new ArrayList<Integer>(Arrays.asList(1,1,2,3,5));
	
	public static int closestFibonacci(int n) {
		
		int result = 0;
		
		if(n < 1) {
			return 0;
		}
		
		// find in cache
		int cur = cache.get(cache.size() - 1);
		if(cur == n) {
			result = n;
		} else if (cur < n) { // update cache
			int pre = cache.get(cache.size() - 2);
			int tmp;
			// check, update cache and get result 
			while(result == 0) {
				tmp = cur + pre;
				if(tmp == n) {
					result = tmp;
				} else if(tmp > n) {
					result = cur;
				}
				
				pre = cur;
				cur = tmp;
				cache.add(tmp);
			}
		} else { // cur > n
			int i = 0;
			while(result == 0) {
				if (cache.get(i) > n) {
					result = cache.get(i-1);
				}
				i++;
			}
		}
			
		return result;
	}
}
