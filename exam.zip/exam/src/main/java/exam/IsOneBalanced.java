package exam;

public class IsOneBalanced {

	public static int isOneBalanced(int[] a) {
		
		int n1s = 0;
		int halfLen = a.length/2;
		int iStart = 0;
		int iEnd = a.length - 1;
		
		if(a.length == 0) {
			return 1;
		}
		
		// if length of array is odd number -> return 0
		if (a.length % 2 == 1)
			return 0;
		
	
		// count beginning 1s
		for (; iStart <= halfLen; iStart++) {
			if(a[iStart] != 1) {
				break;
			}
			
			n1s++;
		}
		
		// if count of beginning 1s > half of length -> return 0
		if(n1s > halfLen)
			return 0;
		
		// plus count ending 1s
		for(; iEnd >= halfLen - 1; iEnd--) {
			if(a[iEnd] != 1) {
				break;
			}
			
			n1s++;
			
			// if sum of beginning 1s and ending 1s > half of length -> return 0
			if(n1s > halfLen)
				return 0;
		}
		
		if(n1s != halfLen) {
			return 0;
		}
		
		// check remaining half of array. If the array contains 1 -> return 0 
		for(int i = iStart; i <= iEnd; i++) {
			if(a[i] == 1) {
				return 0;
			}
		}
		
		return 1; // array is one balanced
	}
}
