package exam;

public class ConvertToBase10 {
	public static int convertToBase10(int[] a, int base) {
		
		if(IsLegalNumber.isLegalNumber(a, base) == 0) {
			return 0;
		}
		
		int result = 0;
		for(int i = 0; i < a.length; i++) {
			result += a[i]*Math.pow(base, a.length - 1 - i);
		}
		return result;
	}
}
