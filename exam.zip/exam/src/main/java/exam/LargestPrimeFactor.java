package exam;

import java.util.ArrayList;
import java.util.List;

public class LargestPrimeFactor {
	public static int largestPrimeFactor(int n) {
		
		int[] primes = getPrimesFactor(n);
		if(primes == null) {
			return 0;
		}
				
		return primes[primes.length-1];
	}
	
	public static int[] getPrimesFactor(int n) {
		
		if(n<=1) {
			return null;
		}
		
		boolean isPrime = IsPrime.isPrime(n) == 1; // besides, it also updates cache.
		
		int[] primes = IsPrime.getPrimesFromCache();
		int i = 0;
		
		List<Integer> t = new ArrayList<Integer>();
		
		while (i < primes.length && primes[i] <= n/2) {
			if(n%primes[i] == 0) {
				t.add(primes[i]);
			}
			i++;
		}
		if(isPrime)
			t.add(n);
		
		int[] res = new int[t.size()];
		for(int j = 0; j < res.length; j++) {
			res[j] = t.get(j);
		}
		
		return res;
	}
}
