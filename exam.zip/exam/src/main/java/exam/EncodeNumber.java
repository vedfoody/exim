package exam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EncodeNumber {
	
	public static int[] encodeNumber(int n) {
		
		if(n <= 1) {
			return null;
		}
		
		int[] res = null;
		List<Integer> list = new ArrayList<Integer>();
		int[] t=null;
		int m = n;
		do {
			t = LargestPrimeFactor.getPrimesFactor(m);
			if(t!= null) {
				for (int p : t) {
					list.add(p);
					m = m/p;
				}
			}
		} while (t != null);
		
		if(m==1) {
			Collections.sort(list);
			res = new int[list.size()];
			for (int i = 0; i < res.length; i++) {
				res[i] = list.get(i);
			}
		}
		
		return res;
	}
}
