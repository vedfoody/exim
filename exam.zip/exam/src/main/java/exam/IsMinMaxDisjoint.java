package exam;

public class IsMinMaxDisjoint {
	public static int isMinMaxDisjoint(int[] a) {
		
		if(a.length < 3) {
			return 0;
		}
		
		int result = 0;
		int max = a[0];
		int min = a[0];
		int iMax = 0;
		int iMin = 0;
		int nMax = 1;
		int nMin = 1;
		
		for(int i = 1; i < a.length; i++) {
			if(max < a[i]) {
				max = a[i];
				iMax = i;
				nMax = 1;
			} else if(max == a[i]) {
				nMax++;
			}
			
			if(min > a[i]) {
				min = a[i];
				iMin = i;
				nMin = 1;
			} else if(min == a[i]) {
				nMin++;
			}
		}
		
		if(nMin == 1 && nMax == 1
				&& Math.abs(iMin - iMax) > 1 ) {
			result = 1;
		}
		
		return result;
	}
}
