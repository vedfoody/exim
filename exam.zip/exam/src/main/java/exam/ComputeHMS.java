package exam;

public class ComputeHMS {
	
	public static int[] computeHMS(int seconds) {
		int[] ret = new int[3];
		
		ret[0] = seconds/3600;
		ret[1] = (seconds%3600)/60;
		ret[2] = (seconds%3600)%60;
		
		return ret;
	}
}
