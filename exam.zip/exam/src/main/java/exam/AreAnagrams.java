package exam;
import java.util.Arrays;

public class AreAnagrams {
	
	public static int areAnagrams(char[] a1, char[] a2) {
		
		if(a1.length != a2.length) {
			return 0;
		}
		
		if(a1.length == 0) {
			return 1;
		}
		
		if(Arrays.equals(a1, a2)) {
			return 1;
		}
		 
		// create a boolean array with each value is false. This array is used to keep track of each letter that is found.
		boolean[] t = new boolean[a2.length]; // default value of boolean is false.
		
		for (char charOfa1 : a1) {
			// find characters of a1 in array a2.
			boolean isFound = false;
			for(int i = 0; i < a2.length; i++) {
				if(charOfa1 == a2[i] ) { // found
					if(!t[i]) { 
						t[i] = true;
						isFound = true;
						break;
					} // else A character of a1 is contained in a2 before -> keep searching in a2
				}
			}
			
			if(!isFound) {
				return 0;
			}
		}
		
		return 1;
	}
}
