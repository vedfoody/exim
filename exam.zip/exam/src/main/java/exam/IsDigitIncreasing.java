package exam;

public class IsDigitIncreasing {
	public static int isDigitIncreasing(int n) {
		
		/*
		 * m + mm + mmm + ... = n
		 * => m*(1 + 11 + 111 + ...) = n 
		 * => 1 + 11 + 111 + ... = n/m
		 *		=> condition 1 : n%m == 0
		 * ( from: https://www.quora.com/What-is-the-sum-of-1+11+111+1111+11111)
		 * (10*(10^b - 1) - 9*b) / 81 = s
		 * 	10*(10^b - 1) - 9*b = s * 81
		*/
		
		int result = 0;
		int m,s,a,j;
		for(int i = 0 ; i < 9 && result == 0; i++) {
			m = i+1;
			if((n%m) == 0) {
				
				s = (n/m)*81;
				j = 1;
				do {
					a = (int) (10*(Math.pow(10, j) - 1) - 9*j);
					j++;
				} while(a < s);
				
				if(s == a) {
					result = 1;
				}
			}
		}
		
		return result;
	}
}
