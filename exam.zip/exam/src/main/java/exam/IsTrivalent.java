package exam;

import java.util.ArrayList;
import java.util.List;

public class IsTrivalent {
	public static int isTrivalent (int[] a) {
		
		if(a.length < 3) {
			return 0;
		}
		
		List<Integer> l = new ArrayList<Integer>();
		
		for(int i = 0; i < a.length && l.size() < 4;i++) {
			if(!l.contains(a[i])) {
				l.add(a[i]);
			}
		}
		
		return l.size() == 3 ? 1 : 0;
	}
}
