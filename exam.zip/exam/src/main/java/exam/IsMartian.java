package exam;

public class IsMartian {

	public static int isMartian(int[] a) {
		
		int n1s = 0;
		int n2s = 0;
		int result = 1;
		
		if(a.length == 0) {
			return 0;
		}
		
		// loop from 0 -> a.length - 1 . So that We can check "two adjacent elements are equal"
		// besides, count 1s and 2s.
		for(int i = 0; i < a.length - 1 && result == 1; i++) {
			if(a[i] == a[i+1]) { // two adjacent elements are equal
				result = 0;
			}
			
			if(a[i] == 1) {
				n1s++;
			}
			
			if(a[i] == 2) {
				n2s++;
			}
		}
		
		if(result == 1) {
			// check the last element.
			int lastElement = a[a.length-1];
			if(lastElement == 1) {
				n1s++;
			} else if(lastElement == 2) {
				n2s++;
			}
			
			if(n1s <= n2s) {
				result = 0;
			}
		}
		
		return result;
	}
}
