package exam;

public class Is235Array {

	public static int is235Array(int[] a) {
		
		int n = 0;
		int nAfter = 0; 
		for (int i : a) {
			
			if (i%2 == 0) { // divisible by 2
				nAfter++;
			}
			
			if (i%3 == 0) { // divisible by 3
				nAfter++;
			}
			
			if (i%5 == 0) { // divisible by 5
				nAfter++;
			}
			
			if(nAfter == n) { // not divisible by 2, 3, 5
				nAfter++;
			}
			
			n = nAfter;
		}
		
		return n == a.length ? 1 : 0;
	}
}
