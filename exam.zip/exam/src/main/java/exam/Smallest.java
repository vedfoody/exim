package exam;

public class Smallest {
	public static int smallest(int n) {
		
		int max = Integer.MAX_VALUE/n;
		int result = -1;
		int j;
		for(int i = 2; i < max && result == -1; i++) {
			j = 1;
			for(; j <= n; j++) {
				if(!isContain2s(i*j)) {
					break;
				}
			}
			
			if(j > n) {
				result = i;
			}
		}
		
		return result;
	}
	
	private static boolean isContain2s(int n) {
		
		boolean res = false;
		
		do {
			if(n%10 == 2) {
				res = true;
			}
			n = n/10;
		} while(n != 0 && !res);
		
		return res;
	}
}
