package exam;

public class LargestDifferenceOfEvens {

	public static int largestDifferenceOfEvens(int[] a) {
		
		int max= Integer.MIN_VALUE;
		int min= Integer.MAX_VALUE;
		int count = 0;
		for (int i : a) {
			if(i%2 == 0) {
				if(i > max) {
					max = i;
				}
				if (i < min) {
					min = i;
				}
				count++;
			}
		}
		
		if(count < 2) {
			return -1;
		}
		
		return max - min;
	}
}
