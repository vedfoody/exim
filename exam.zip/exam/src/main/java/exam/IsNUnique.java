package exam;

public class IsNUnique {
	public static int isNUnique(int[] a, int n) {
		
		if (a.length < 2) {
			return 0;
		}
		
		int count = 0;
		for (int i = 0; i < a.length-1 && count < 2; i++) {
			for(int j = i + 1; j < a.length && count < 2; j++) {
				if(a[i] + a[j] == n) {
					count++;
				}
			}
		}
		
		return count == 1 ? 1 : 0;
	}
}
