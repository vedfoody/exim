package exam;

public class IsVanilla {
	public static int isVanilla(int[] a) {
		
		if(a.length == 0) {
			return 1;
		}
		
		int result = 1;
		int d = a[0]%10;
		int n;
		for(int i = 0; i < a.length && result == 1; i++) {
			n = a[i];
			if(n < 0) {
				n = -n; // convert to positive number;
			}
			
			do {
				if(n%10 != d) {
					result = 0;
				}
				n = n/10;
			} while (n != 0 && result == 1);
		}
		
		return result;
	}
}
