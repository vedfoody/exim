package exam;

public class LargestAdjacentSum {

	public static int largestAdjacentSum(int[] a) {
		
		if(a.length < 2) {
			return 0;
		}
		
		int max = Integer.MIN_VALUE;
		int s;
		for(int i = 0; i < a.length - 1; i++) {
			s = a[i] + a[i+1];
			if(s > max) {
				max = s;
			}
		}
		return max;
	}
}
