package exam;

public class IsFactorialPrime {

	public static int isFactorialPrime(int n) {

		int result = 0;
		
		if (IsPrime.isPrime(n) == 1) {
			int f = 1;
			int i = 2;
			n -= 1;
			while (f < n) {
				f *= i++;
			}
			
			if(f == n) {
				result = 1;
			}
		}
		
		return result;
	}
}
