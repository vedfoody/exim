package exam;

public class CountRepresentations {
	public static int countRepresentations(int numRupees) {
		
		if(numRupees <= 0) {
			return 0;
		}
		
		int remain20, remain10, remain5, remain2;
		int count = 0;
		for (int rupee20=0; rupee20 <= numRupees/20; rupee20++) {
			remain20 = numRupees - rupee20*20;
			for (int rupee10=0; rupee10 <= remain20/10; rupee10++) {
				remain10 = remain20 - rupee10*10;
				for (int rupee5=0; rupee5 <= remain10/5; rupee5++) {
					remain5 = remain10 - rupee5*5;
					for (int rupee2=0; rupee2 <= remain5/2; rupee2++) {
						remain2 = remain5 - rupee2*2;
						for (int rupee1=0; rupee1 <= remain2; rupee1++) {
							if (remain2 - rupee1 == 0) {
								count++;
							}
						}
					}
				}
			}	
		}
			
		return count;
	}
}
