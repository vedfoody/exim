package exam;

public class IsCubePowerful {
	public static int isCubePowerful(int n){
		
		if(n <= 0) {
			return 0;
		}
		
		int mod;
		int d = n;
		int s = 0;
		do {
			mod = d%10;
			s += mod*mod*mod;
			d = d/10;
		} while(d != 0);
		
		return s==n ? 1 : 0;
	}
}
