package exam;

public class DoIntegerBasedRounding {

	public static void doIntegerBasedRounding(int[] a, int n) {
		
		if(n<=0) {
			return;
		}
		
		for(int i = 0 ; i < a.length; i++) {
			a[i] = doIntegerBasedRounding(a[i], n);
		}
	}
	
	private static int doIntegerBasedRounding(int a, int n) {
		
		if(n <= 0 || a < 0)
			return a;
		
		int r1 = (a/n)*n;
		int r2 = r1 + n;
		
		return a - r1 < r2 - a ? r1 : r2;
	}
}
