package exam;

public class IsOddHeavy {

	public static int isOddHeavy(int[] a) {
		
		if(a.length == 0) {
			return 0;
		}
		
		int result = 0;
		int nOdd = 0;
		int minOdd = Integer.MAX_VALUE;
		int maxEven = Integer.MIN_VALUE;
		
		for (int i : a) {
			if(i%2 == 0) { // even
				if(maxEven < i) {
					maxEven = i;
				}
			} else { // odd
				nOdd++;
				if(minOdd > i) {
					minOdd = i;
				}
			}
		}
		
		if(nOdd > 0 && minOdd > maxEven) {
			result = 1;
		}
		
		return result;
	}
	
}
