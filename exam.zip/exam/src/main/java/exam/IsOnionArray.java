package exam;

public class IsOnionArray {

	public static int isOnionArray(int[] a) {
		
		int n = a.length/2;
		int result = 1;
		for(int j = 0; j < n && result == 1; j++) {
			if(a[j] + a[a.length - j - 1] > 10) {
				result = 0;
			}
		}
		
		return result;
	}
}
