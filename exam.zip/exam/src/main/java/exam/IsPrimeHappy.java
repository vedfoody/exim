package exam;

public class IsPrimeHappy {

	public static int isPrimeHappy(int n) {
	
		IsPrime.isPrime(n); // update cache
		int[] primes = IsPrime.getPrimesFromCache();
		
		int i = 0;
		int s = 0;
		while(i < primes.length && primes[i] < n) {
			s += primes[i]; 
			i++;
		}
		
		return (s!=0 && (s%n)==0) ? 1 : 0;
	}
	
}
