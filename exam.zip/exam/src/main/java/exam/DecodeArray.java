package exam;

public class DecodeArray {

	public static int decodeArray(int[] a) {
		
		if(a.length == 0 || a[a.length - 1] != 1) {
			throw new IllegalArgumentException();
		}
		
		
		int i = 0;
		boolean isNeg = false;
		if(a[0] < 0) {
			if(a[0] == -1) {
				isNeg = true;
				i = 1;
			} else {
				throw new IllegalArgumentException();
			}
		}
		
		int n = 0;
		int c = 0;
		for(; i < a.length; i++) {
			if(a[i] == 0) {
				c++;
				if(c==10) {
					throw new IllegalArgumentException();
				}
			} else if (a[i] == 1) {
				n = n*10 + c;
				c = 0;
			} else {
				throw new IllegalArgumentException();
			}
		}
		
		return isNeg ? -n : n;
	}
}
