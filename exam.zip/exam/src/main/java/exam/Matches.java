package exam;

public class Matches {
	public static int matches(int[] a, int[] p) {
		
		int result = 1;
		
		int j = 0;
		int t;
		for(int i = 0; i < p.length && result == 1; i++) {
			if(p[i] == 0) {
				result = 0;
			} else {
				t = j + Math.abs(p[i]);
				if(t > a.length) {
					result = 0;
				} else {
					for (; j < t && result == 1; j++) {
						if(p[i] < 0) {
							if(a[j] >= 0) {
								result = 0; 
							}
						} else {
							if(a[j] <= 0) {
								result = 0; 
							}
						}
					}
				}
			}
		}
		
		return result;
	}
}
