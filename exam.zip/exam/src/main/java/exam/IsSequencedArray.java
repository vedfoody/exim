package exam;

public class IsSequencedArray {

	public static int isSequencedArray(int[] a, int m, int n) {
		
		if(m > n) {
			return 0;
		}
		
		int result = 1;
		int matches = 0;
		for(int i = 0 ; i < a.length && result == 1; i++) {
			if(a[i] == m) {
				matches++;
			} else if(matches == 0 || m >= n) {
				result = 0;
			} else {
				m++;
				i -= 1;
				matches = 0;
			}
		}
		
		if(m != n) {
			result = 0;
		}
		
		return result;
	}
}
