package exam;

public class IsPairedN {

	/* 
	 * Calculate loop:
	 *   We have conditions to find index-pair:
	 *   0 <= i < l
	 *   0 <= j < l
	 *   i + j = n
	 * 	 i != j
	 * 
	 *	=> 	0 <= n < 2*l
	 *		i != n/2
	 *		n-l <= i < n and i >= 0
	 *	=> Our loop
	 *  	From 0 if n-l is negative . Else is n-l.
	 *		To n/2 if n is even number else n/2 + 1. (Because i and j can swap)
	*/
	
	public static int isPairedN(int[] a, int n) {
		
		int l = a.length;
		if(l == 0) {
			return 0;
		}
		
		if( n < 0 || n >= 2*l) {
			return 0;
		} // else means 0 <= n < 2*l
		
		int i = n-l > 0 ? n-l : 0;
		int result = 0;
		int end = n/2 + n%2;
		for(; i < end && result == 0; i++) {
			int j = n-i;
			if(j < l) {
				if(a[i] + a[j] == n ) {
					result = 1;
				}
			}
		}
		return result;
	}
}
