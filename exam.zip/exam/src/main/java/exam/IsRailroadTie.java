package exam;

public class IsRailroadTie {
	public static int isRailroadTie(int[] a) {
		/* 	
		 * {1, 2, 0, 3, -18, 0, 2, 2} -> isRailroadTie
		 *  0        1          2		(a.length/3)
		 */
		int mod = a.length%3;
		if(mod < 2) {
			return 0;
		}
		
		int result = 1;
		int m = a.length/3;
		
		for(int i = 0; i < m && result == 1; i++) {
			if( a[i*3] == 0 || a[i*3+1] == 0 || a[i*3+2] != 0) {
				result = 0;
			}
		}
		
		if(result == 1) {
			if(mod == 2) { // need to check 2 last elements.
				if(a[m*3] == 0 || a[m*3+1] == 0 ) {
					result = 0;
				}
			}
		}
	
		return result;
	}
}