package exam;

public class FilterArray {
	public static int[] filterArray(int[] a, int n) {

		if(n== 0) {
			return new int[0];
		} else if(n<0) {
			return null;
		}	
		
		int n1s = 0;
		int t = 0;
		//step 1: Compute the size of the returned array by counting the number of 1s in the binary representation of n
		for(int i = 1; i != 0; i = i << 1) {
			if((n&i) != 0) {
				// is selected
				if(t >= a.length) {
					return null; // because there is no a[t]
				}
				n1s++;
			}
			t++;
		}
	
		// step2: Allocate an array of the required size
		int[] res = new int[n1s];
		int b = 1;
		t = 0;
		// step3: Fill the allocated array with elements selected from the input array
		for(int i = 0; i < a.length; i++) {
			if((n&b) != 0) {
				// is selected
				res[t++] = a[i];
			}
			b <<= 1;
		}
		
		return res;
	}
}
