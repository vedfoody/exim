package exam;

import java.util.ArrayList;
import java.util.List;

public class ClusterCompression {
	public static int[] clusterCompression(int[] a) {
		
		if(a.length == 0) {
			return new int[] {};
		}
		
		List<Integer> l = new ArrayList<Integer>();
		int t = a[0];
		l.add(a[0]);
		
		for(int i = 1; i < a.length; i++) {
			if(a[i] != t) {
				t = a[i];
				l.add(t);
			}
		}
		
		int [] res = new int[l.size()];
		for (int i = 0; i < res.length; i++) {
			res[i] = l.get(i);
		}
		
		return res;
	}
}
