package exam;

public class IsSquare {

	public static int isSquare(int n) {
		
		if(n<0) {
			return 0;
		}
		
		int i = 0;
		int square;
		do {
			square = i*i;
			i++;
		} while ( square < n);
		
		return square == n ? 1 : 0;
			
	}
	
	
}
