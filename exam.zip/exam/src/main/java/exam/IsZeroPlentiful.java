package exam;

public class IsZeroPlentiful {
	
	public static int isZeroPlentiful(int[] a) {
		
		int res = 0;
		boolean isInSequence = false;
		int n0 = 1;
		for (int i = 0; i < a.length; i++) {
			if(isInSequence) {
				if(a[i] == 0 ) {
					n0++;
				} else { // finish a sequence
					if(n0 >= 4) {
						res++;
					}
					
					n0 = 1; // reset n0 to 1
					isInSequence = false;
				}
			} else {
				if(a[i] == 0) { // start a sequence. n0 = 1;
					isInSequence = true;
				}
			}
		}
		
		// In case, last sequence in array. Eg: {0, 0, 0 ,0 ,0 } 
		if(n0 >= 4) {
			res++;
		}
		
		return res;
	}
}
