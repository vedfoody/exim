package exam;

public class IsMercurial {
	
	public static int isMercurial(int[] a) {
		
		int i1s = -1;
		boolean isPrecededBy1 = false;
		int result = 1;
		
		
		if(a.length < 3) {
			return 1;
		}
		
		for(int i = 0; i<a.length && result==1; i++) {
			if(!isPrecededBy1) {
				if(a[i] == 1) {
					i1s = i;
				} else if(a[i] == 3) {
					if( 0 <= i1s && i1s < i) { // 3 is preceded by a 1 
						isPrecededBy1 = true;
					}
				}
			} else {
				if(a[i] == 1) {
					result = 0; // is not mercurial -> out loop and return.
				}
			}
		}
		
		return result;
	}
	
}
