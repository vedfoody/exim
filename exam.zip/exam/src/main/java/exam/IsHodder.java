package exam;

public class IsHodder {
	
	public static int isHodder(int n) {
		
		int result = 0;
		
		if (IsPrime.isPrime(n) == 1) {
			int a = 2;
			n += 1;
			while (a < n) {
				a <<= 1;
			}
			
			if(a == n) {
				result = 1;
			}
		}
		
		return result;
	}
}
