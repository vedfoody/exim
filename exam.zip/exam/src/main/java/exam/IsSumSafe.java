package exam;

public class IsSumSafe {
	public static int isSumSafe(int[] a) {
		
		if(a.length == 0) {
			return 0;
		}
		
		int result = 1;;
		int s = 0;
		for (int i : a) {
			s += i;
		}
		
		for (int i : a) {
			if(i==s) {
				result = 0;
				break;
			}
		}
		
		return result;
	}
}
