package exam;

import java.util.ArrayList;
import java.util.List;

public class IsIsolated {
	public static int isIsolated(long n) {
		
		if ( n < 1 || n > 2097151)
			return -1;
		
		int result = 1;
		long square = n*n;
		long cube = n*n*n;
		
		// get list of digits of square.
		List<Integer> squareDigits = new ArrayList<Integer>();
		int t;
		do {
			t = (int)(square%10);
			if(!squareDigits.contains(t)) {
				squareDigits.add(t);
			}
			square = square/10;
		} while (square != 0);
		
		// 
		do {
			t = (int)(cube%10);
			if(squareDigits.contains(t)) {
				result = 0;
			}
			cube = cube/10;
		} while (cube != 0 && result == 1);
		
	
		return result;
	}
}
