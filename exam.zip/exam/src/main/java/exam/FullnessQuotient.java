package exam;

public class FullnessQuotient {

	public static int fullnessQuotient(int n) {
		
		if( n <= 0) {
			return -1;
		}
		
		int count = 0;
		for(int i = 2; i <=9; i++) {
			if(!is0sInRepresentation(n, i)) {
				count++;
			}
		}
		
		return count;
	}
	
	private static boolean is0sInRepresentation(int n, int base) {
		
		boolean res = false;
		
		int m = n;
		do {
			if(m%base == 0) {
				res = true;
			}
			m = m/base;
			
		} while(!res && m != 0);
		
		return res;
	}
}
