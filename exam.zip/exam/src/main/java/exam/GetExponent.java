package exam;

public class GetExponent {

	public static int getExponent(int n, int p) {
		
		if(p <= 1) {
			return -1;
		}
		
		int max = 0;
		int i = 1;
		int t=p;
		
		if(n<0) {
			n = -n;
		}
		
		do {
			if(n%t == 0) {
				max = i;
			}
			t *= p;
			i++;
		} while(t <= n);
		
		return max;
	}
	
}
