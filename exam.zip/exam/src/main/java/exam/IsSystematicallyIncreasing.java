package exam;

public class IsSystematicallyIncreasing {

	public static int isSystematicallyIncreasing(int[] a) {
		
		/* Eg:n = 6
		 *   1 2   3     4       5         6
		 * { 1 1 2 1 2 3 1 2 3 4 1 2 3 4 5 1 2 3 4 5 6 }
		 * 
		 * => length of array = 1+2+3+4+5+6 . This is Arithmetic progression with d=1 ( check IsTriagular)
		 * 
		 */
		
		// check length of array
		if (IsTriangular.isTriangular(a.length) == 0) {
			return 0;
		}
		
		int result = 1;
		int b = 1;
		for(int i = 0; i < a.length && result==1;) {
			for(int j = 1; j<=b && result==1; j++) {
				if(a[i] != j) {
					result = 0;
				}
				i++;
			}
			b++;
		}
		
		return result;
	}
	
}
