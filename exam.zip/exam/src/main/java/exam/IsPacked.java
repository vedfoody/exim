package exam;

import java.util.ArrayList;
import java.util.List;

public class IsPacked {
	public static int isPacked(int[] a) {
		
		int result = 1;
		
		if(a == null) {
			return 0;
		}
		
		if(a.length == 0) {
			return 1;
		}
		
		List<Integer> exists = new ArrayList<Integer>();
		int t = a[0];
		int matches = t;
		exists.add(t);
		for(int i = 0; i<a.length && result==1; i++) {
			if(a[i] > 0) {
				if(a[i] == t) {
					if(matches == 0) {
						matches = t; 
					}
					matches--;
				} else {
					if(matches == 0) {
						t = a[i]; // update t;
						if(exists.contains(t)) { // check existing.
							result = 0;
						} else {
							matches = a[i];
							i--; // move to previous index and re-check
						}
					} else {
						result = 0;
					}
				}
			} else {
				result = 0;
			}
		}
		
		if(result == 1 && matches != 0) {
			result = 0;
		}
		
		return result;
	}
}
