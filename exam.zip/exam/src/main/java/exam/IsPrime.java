package exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IsPrime {

	private static List<Integer> cache = new ArrayList<Integer>(Arrays.asList(2, 3, 5, 7, 11, 13));
	
	public static int isPrime(int n) {
		int result = 0;
		
		int last = cache.get(cache.size() - 1);
		
		if(last == n) {
			result = 1;
		} else if (last > n) {
			if(cache.contains(n)) {
				result = 1;
			} else {
				result = 0;
			}
		} else { // find prime numbers from last element of cache to n and add to cache.
			// step1 : get all prime number by input end
			final boolean[] primes = new boolean[n+1];
			Arrays.fill(primes, true);
			primes[0] = false;
			primes[1] = false;
			
			int sqrtEnd = (int) Math.sqrt(n);
			
			for(int i = 2; i <= sqrtEnd; i++ ) {
				if(primes[i]) {
					for(int j = i*i; j <= n; j+= i ) {
						primes[j] = false;
					}
				}
			}
			
			// step2 : count primes by condition start 
			for (int i = last+1; i <= n; i++) {
				if(primes[i]) {
					cache.add(i);
				}
			}
			
			if(cache.get(cache.size()-1) == n) {
				result = 1;
			}
		}
		
		return result;
	}
	
	public static int[] getPrimesFromCache() {
		
		int[] res = new int[cache.size()];
		for (int i = 0; i < res.length; i++) {
			res[i] = cache.get(i);
		}
		
		return res;
	}
}
