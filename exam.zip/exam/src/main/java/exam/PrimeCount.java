package exam;

import java.util.Arrays;

public class PrimeCount {
	
	public static int primeCount(int start, int end) {
		int count = 0;
		
		if(start < 2) {
			start = 2; // primes are greater than 1
		}
		
		if(end < 2 )  {
			return 0;  // By definition, 1 is not a prime number
		}
		
		if(start > end)  {
			return 0; // start must be less than or equal to end
		}
		
		// step1 : get all prime number by input end
		final boolean[] primes = new boolean[end+1];
		Arrays.fill(primes, true);
		primes[0] = false;
		primes[1] = false;
		
		int sqrtEnd = (int) Math.sqrt(end);
		
		for(int i = 2; i <= sqrtEnd; i++ ) {
			if(primes[i]) {
				for(int j = i*i; j <= end; j+= i ) {
					primes[j] = false;
				}
			}
		}
		
		// step2 : count primes by condition start 
		for (int i = start; i <= end; i++) {
			if(primes[i]) {
				count++;
			}
		}
		
		return count;
	}
}
