package exam;

public class IsSequentiallyBounded {
	public static int isSequentiallyBounded(int[] a) {
		
		if(a.length == 0) {
			return 1;
		}
		
		int result = 1;
		int t = a[0];
		int nt = 1;
		for(int i = 1; i < a.length && result == 1; i++) {
			if(nt >= t) {
				result = 0;
			} else {
				if (a[i] == t) {
					nt++;
				} else if(a[i] > t) { // next
					t = a[i];
					nt = 1;
				} else { // array is not in ascending order.
					result = 0;
				}
			}
		}
		
		return result;
	}
}
