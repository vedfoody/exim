package exam;

public class IsDivisible {
	public static int isDivisible(int[] a, int divisor) {
		
		int result = 1;
		
		for (int i : a) {
			if(i%divisor != 0) {
				result = 0;
				break;
			}
		}
		
		return result;
	}
}
