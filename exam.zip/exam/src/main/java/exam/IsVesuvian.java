package exam;

public class IsVesuvian {
	
	public static int isVesuvian(int n) {
		
		// a*a + b*b = n => a,b < sqrt(n)  
		int t = (int)Math.sqrt(n);
		int a,b;
		int count = 0;

		// use string builder for debug
		//StringBuilder sb = new StringBuilder();
		//sb.append("" + n + "(");
		for(int i = 1; i<=t && count < 2; i++) {
			a = i*i;
			b = n - a;
			for(int j = t; j >= i; j--) { // reverse to check b
				if(j*j <= b) {
					if(j*j == b) {
						//sb.append("" + a + "+" + b + ",");
						count++;
					}
					break;
				}
			}
		}
		
		if(count == 2) {
			//sb.setCharAt(sb.length()-1, ')');
			//System.out.println(sb);
			return 1;
		}
		
		return 0;
	}
	
}
