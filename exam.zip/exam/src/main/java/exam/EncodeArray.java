package exam;

import java.util.ArrayList;
import java.util.List;

public class EncodeArray {
	
	public static int[] encodeArray(int n) {
		
		List<Integer> list = new ArrayList<Integer>();
		
		int mod;
		boolean isNegative = false;
		
		if(n<0) {
			isNegative = true;
			n = -n;
		}
		
		do {
			mod = n%10;
			list.add(1);
			for(int i = 0; i < mod; i++) {
				list.add(0);
			}
			n = n/10;
		} while(n != 0);
		
		if(isNegative) {
			list.add(-1);
		}
	
		int[] result = new int[list.size()];
		for(int i = 0; i < result.length; i++) {
			result[i] = list.get(result.length - i - 1); // need to reverse
		}
		
		return result;
	}
}
