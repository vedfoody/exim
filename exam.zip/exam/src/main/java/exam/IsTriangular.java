package exam;

public class IsTriangular {
	
	/*
	 * 1 + 2 +...+j This is Arithmetic progression with d=1 . https://en.wikipedia.org/wiki/Arithmetic_progression
	 * => 2*n = j*j + j
	 * => j*j + j - 2*n = 0
	 * => n is Triangular if "j*j + j - 2*n = 0", j is integer and j > 0   
	 */
	public static int isTriangular(int n) {
		
		int result = 0;
		
		if(n<1) {
			return 0;
		}
		
		// find j from "j*j + j - 2*n = 0" // giai phuong trinh bac 2
		// delta = b*b - 4ac; with a = 1, b=1, c = -2*n
		int delta = 1 + 8*n;
		
		// j1 = (-b + sqrt(delta))/2a
		// j2 = (-b - sqrt(delta))/2a
		// Because j is integer and j > 0 and n > 0 => We use formula of j1 to get j
		double j = (-1 + Math.sqrt(delta))/2;
		if((j % 1) == 0) { // check a double number is integer
			result = 1;
		} // else j is not integer
		
		return result;
	}
}
