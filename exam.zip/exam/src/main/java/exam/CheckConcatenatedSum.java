package exam;

public class CheckConcatenatedSum {
	public static int checkConcatenatedSum(int n, int catlen) {
		
		int m = n;
		int s = 0;
		do {
			s += concatenate(m%10, catlen);
			m = m/10;
		} while (m != 0);
		
		return s==n ? 1 : 0;
	}
	
	private static int concatenate(int n, int catlen) {
		
		int res = 0;
		for(int i = 0; i < catlen; i++) {
			res = res*10 + n;
		}
		return res;
	}
}
