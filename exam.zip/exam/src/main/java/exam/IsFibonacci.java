package exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IsFibonacci {

	private static List<Integer> cache = new ArrayList<Integer>(Arrays.asList(1,1,2,3,5));
	
	public static int isFibonacci(int n) {
		
		int result = 0;
		
		// find in cache		
		int cur = cache.get(cache.size() - 1);
		if( cur == n) {
			result = 1;
		} else if (cur > n) {
			if (cache.contains(n)) {
				result = 1;
			} else {
				result = 0;
			}
		}
		
		int pre = cache.get(cache.size() - 2);
		int tmp;
		// check and update cache
		while(result == 0) {
			tmp = cur + pre;
			pre = cur;
			cur = tmp;
			cache.add(cur);
			if(cur == n) {
				result = 1;
			} else if(cur > n) {
				break;
			}
		}
		
		return result;
	}
}
