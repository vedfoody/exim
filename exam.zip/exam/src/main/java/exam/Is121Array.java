package exam;

public class Is121Array {
	public static int is121Array(int[] a) {
		
		int result = 1;
		int i = 0;
		for(; i < a.length/2; i++) {
			if(a[i] != 1 || a[a.length - i -1] != 1) {
				break;
			} 
		}
		
		if(i == a.length/2 && a.length%2 == 0) {
			return 0;
		}
		
		int start = i;
		int end = a.length - i;
		for (int j =  start; j < end && result == 1; j++) {
			if(a[j] != 2) {
				result = 0;
			}
		}
		
		return result;
	}
}
