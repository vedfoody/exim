package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestLargestDifferenceOfEvens {

	@Test
	public void test() {
		int[] a1 = {-2, 3, 4, 9};
		int[] a2 = {1, 3, 5, 9};
		int[] a3 = {1, 18, 5, 7, 33};
		int[] a4 = {2, 2, 2, 2};
		int[] a5 = {1, 2, 1, 2, 1, 4, 1, 6, 4};
		
		Assert.assertEquals(String.format("largestDifferenceOfEvens(%s)", Arrays.toString(a1)), 6, LargestDifferenceOfEvens.largestDifferenceOfEvens(a1));
		Assert.assertEquals(String.format("largestDifferenceOfEvens(%s)", Arrays.toString(a2)), -1, LargestDifferenceOfEvens.largestDifferenceOfEvens(a2));
		Assert.assertEquals(String.format("largestDifferenceOfEvens(%s)", Arrays.toString(a3)), -1, LargestDifferenceOfEvens.largestDifferenceOfEvens(a3));
		Assert.assertEquals(String.format("largestDifferenceOfEvens(%s)", Arrays.toString(a4)), 0, LargestDifferenceOfEvens.largestDifferenceOfEvens(a4));
		Assert.assertEquals(String.format("largestDifferenceOfEvens(%s)", Arrays.toString(a5)), 4, LargestDifferenceOfEvens.largestDifferenceOfEvens(a5));
	}	
}
