package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsSquare {

	@Test
	public void test() {

		Assert.assertEquals("isSquare(4)", 1, IsSquare.isSquare(4));
		Assert.assertEquals("isSquare(25)", 1, IsSquare.isSquare(25));
		Assert.assertEquals("isSquare(-4)", 0, IsSquare.isSquare(-4));
		Assert.assertEquals("isSquare(8)", 0, IsSquare.isSquare(8));
		Assert.assertEquals("isSquare(0)", 1, IsSquare.isSquare(0));
	}
}
