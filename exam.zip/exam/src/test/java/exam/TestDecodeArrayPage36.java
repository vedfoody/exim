package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestDecodeArrayPage36 {

	@Test
	public void test() {

		int[] a1 = {0, -3, 0, -4, 0};
		int[] a2 = {-1, 5, 8, 17, 15};
		int[] a3 = {1, 5, 8, 17, 15};
		int[] a4 = {111, 115, 118, 127, 125};
		int[] a5 = {1, 1};
		
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a1)), 3344, DecodeArrayPage36.decodeArray(a1));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a2)), -6392, DecodeArrayPage36.decodeArray(a2));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a3)), 4392, DecodeArrayPage36.decodeArray(a3));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a4)), 4392, DecodeArrayPage36.decodeArray(a4));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a5)), 0, DecodeArrayPage36.decodeArray(a5));
	}
}
