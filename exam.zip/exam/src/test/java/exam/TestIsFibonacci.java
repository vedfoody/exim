package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsFibonacci {

	@Test
	public void test() {	
		Assert.assertEquals("isFibonacci(1)", 1, IsFibonacci.isFibonacci(1));
		Assert.assertEquals("isFibonacci(1)", 1, IsFibonacci.isFibonacci(1));
		Assert.assertEquals("isFibonacci(2)", 1, IsFibonacci.isFibonacci(2));
		Assert.assertEquals("isFibonacci(3)", 1, IsFibonacci.isFibonacci(3));
		Assert.assertEquals("isFibonacci(5)", 1, IsFibonacci.isFibonacci(5));
		Assert.assertEquals("isFibonacci(8)", 1, IsFibonacci.isFibonacci(8));
		Assert.assertEquals("isFibonacci(10)", 0, IsFibonacci.isFibonacci(10));
		Assert.assertEquals("isFibonacci(13)", 1, IsFibonacci.isFibonacci(13));
		Assert.assertEquals("isFibonacci(21)", 1, IsFibonacci.isFibonacci(21));
		Assert.assertEquals("isFibonacci(34)", 1, IsFibonacci.isFibonacci(34));
		Assert.assertEquals("isFibonacci(21)", 0, IsFibonacci.isFibonacci(27));
	}
}
