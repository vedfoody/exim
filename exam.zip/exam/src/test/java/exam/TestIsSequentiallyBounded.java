package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsSequentiallyBounded {

	@Test
	public void test() {

		int[] a1 = {0, 1};
		int[] a2 = {-1, 2};
		int[] a3 = {};
		int[] a4 = {5, 5, 5, 5};
		int[] a5 = {5, 5, 5, 2, 5};
		int[] a6 = {2, 3, 3, 99, 99, 99, 99, 99};
		int[] a7 = {1, 2, 3};
		int[] a8 = {2, 3, 3, 3, 3};
		int[] a9 = {12, 12, 9};
		
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a1)), 0, IsSequentiallyBounded.isSequentiallyBounded(a1));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a2)), 0, IsSequentiallyBounded.isSequentiallyBounded(a2));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a3)), 1, IsSequentiallyBounded.isSequentiallyBounded(a3));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a4)), 1, IsSequentiallyBounded.isSequentiallyBounded(a4));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a5)), 0, IsSequentiallyBounded.isSequentiallyBounded(a5));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a6)), 1, IsSequentiallyBounded.isSequentiallyBounded(a6));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a7)), 0, IsSequentiallyBounded.isSequentiallyBounded(a7));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a8)), 0, IsSequentiallyBounded.isSequentiallyBounded(a8));
		Assert.assertEquals(String.format("isSequentiallyBounded(%s)",Arrays.toString(a9)), 0, IsSequentiallyBounded.isSequentiallyBounded(a9));
	}
}
