package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsOneBalanced {

	@Test
	public void test() {
		int[] a1 = {1, 1, 1, 2, 3, -18, 45, 1};
		int[] a2 = {1, 1, 1, 2, 3, -18, 45, 1, 0};
		int[] a3 = {1, 1, 2, 3, 1, -18, 26, 1};
		int[] a4 = {};
		int[] a5 = {3, 4, 1, 1};
		int[] a6 = {1, 1, 3, 4};
		int[] a7 = {3, 3, 3, 3, 3, 3};
		int[] a8 = {1, 1, 1, 1, 1, 1};
		
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a1)), 1, IsOneBalanced.isOneBalanced(a1));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a2)), 0, IsOneBalanced.isOneBalanced(a2));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a3)), 0, IsOneBalanced.isOneBalanced(a3));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a4)), 1, IsOneBalanced.isOneBalanced(a4));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a5)), 1, IsOneBalanced.isOneBalanced(a5));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a6)), 1, IsOneBalanced.isOneBalanced(a6));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a7)), 0, IsOneBalanced.isOneBalanced(a7));
		Assert.assertEquals(String.format("isOneBalanced(%s)", Arrays.toString(a8)), 0, IsOneBalanced.isOneBalanced(a8));
	}
}
