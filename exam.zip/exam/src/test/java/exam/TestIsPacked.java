package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsPacked {

	@Test
	public void test() {

		int[] a1 = {2, 2, 1};
		int[] a2 = {2, 2, 1, 2, 2};
		int[] a3 = {4, 4, 4, 4, 1, 2, 2, 3, 3, 3};
		int[] a4 = {7, 7, 7, 7, 7, 7, 7, 1};
		int[] a5 = {7, 7, 7, 7, 1, 7, 7, 7};
		int[] a6 = {7, 7, 7, 7, 7, 7, 7};
		int[] a7 = {};
		int[] a8 = {1, 2, 1};
		int[] a9 = {2, 1, 1};
		int[] a10 = {-3, -3, -3};
		int[] a11 = {0, 2, 2};
		int[] a12 = {2, 1, 2};
		
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a1)), 1, IsPacked.isPacked(a1));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a2)), 0, IsPacked.isPacked(a2));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a3)), 1, IsPacked.isPacked(a3));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a4)), 1, IsPacked.isPacked(a4));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a5)), 0, IsPacked.isPacked(a5));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a6)), 1, IsPacked.isPacked(a6));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a7)), 1, IsPacked.isPacked(a7));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a8)), 0, IsPacked.isPacked(a8));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a9)), 0, IsPacked.isPacked(a9));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a10)), 0, IsPacked.isPacked(a10));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a11)), 0, IsPacked.isPacked(a11));
		Assert.assertEquals(String.format("isPacked(%s)",Arrays.toString(a12)), 0, IsPacked.isPacked(a12));
	}
}
