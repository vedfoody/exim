package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestSmallest {

	@Test
	public void test() {

		Assert.assertEquals("smallest(3)", 124, Smallest.smallest(3));
		Assert.assertEquals("smallest(4)", 624, Smallest.smallest(4));
		Assert.assertEquals("smallest(5)", 624, Smallest.smallest(5));
		Assert.assertEquals("smallest(6)", 642, Smallest.smallest(6));
		Assert.assertEquals("smallest(7)", 4062, Smallest.smallest(7));
	}
}
