package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestComputeHMS {

	@Test
	public void test() {
		Assert.assertArrayEquals("computeHMS(3735)",new int[] {1, 2, 15}, ComputeHMS.computeHMS(3735));
		Assert.assertArrayEquals("computeHMS(380)",new int[] {0, 6, 20}, ComputeHMS.computeHMS(380));
		Assert.assertArrayEquals("computeHMS(3650)",new int[] {1, 0, 50}, ComputeHMS.computeHMS(3650));
		Assert.assertArrayEquals("computeHMS(55)",new int[] {0, 0, 55}, ComputeHMS.computeHMS(55));
		Assert.assertArrayEquals("computeHMS(0)",new int[] {0, 0, 0}, ComputeHMS.computeHMS(0));
	}
}
