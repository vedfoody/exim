package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestLargestAdjacentSum {

	@Test
	public void test() {
		int[] a1 = {1, 2, 3, 4};
		int[] a2 = {18, -12, 9, -10};
		int[] a3 = {1,1,1,1,1,1,1,1,1};
		int[] a4 = {1,1,1,1,1,2,1,1,1};
		
		Assert.assertEquals(String.format("largestAdjacentSum(%s)", Arrays.toString(a1)), 7, LargestAdjacentSum.largestAdjacentSum(a1));
		Assert.assertEquals(String.format("largestAdjacentSum(%s)", Arrays.toString(a2)), 6, LargestAdjacentSum.largestAdjacentSum(a2));
		Assert.assertEquals(String.format("largestAdjacentSum(%s)", Arrays.toString(a3)), 2, LargestAdjacentSum.largestAdjacentSum(a3));
		Assert.assertEquals(String.format("largestAdjacentSum(%s)", Arrays.toString(a4)), 3, LargestAdjacentSum.largestAdjacentSum(a4));
	}
}
