package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsMercurial {

	@Test
	public void test() {
		int[] a1 = {1, 2, 10, 3, 15, 1, 2, 2};
		int[] a2 = {5, 2, 10, 3, 15, 1, 2, 2};
		int[] a3 = {1, 2, 10, 3, 15, 16, 2, 2};
		int[] a4 = {3, 2, 18, 1, 0, 3, -11, 1, 3};
		int[] a5 = {2, 3, 1, 1, 18};
		int[] a6 = {8, 2, 1, 1, 18, 3, 5};
		int[] a7 = {3, 3, 3, 3, 3, 3};
		int[] a8 = {1};
		int[] a9 = {};
	
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a1)), 0, IsMercurial.isMercurial(a1));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a2)), 1, IsMercurial.isMercurial(a2));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a3)), 1, IsMercurial.isMercurial(a3));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a4)), 0, IsMercurial.isMercurial(a4));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a5)), 1, IsMercurial.isMercurial(a5));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a6)), 1, IsMercurial.isMercurial(a6));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a7)), 1, IsMercurial.isMercurial(a7));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a8)), 1, IsMercurial.isMercurial(a8));
		Assert.assertEquals(String.format("isMercurial(%s)", Arrays.toString(a9)), 1, IsMercurial.isMercurial(a9));
	}	
}
