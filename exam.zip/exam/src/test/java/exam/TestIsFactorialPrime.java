package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsFactorialPrime {

	@Test
	public void test() {
		
		Assert.assertEquals("isFactorialPrime(2)", 1, IsFactorialPrime.isFactorialPrime(2));
		Assert.assertEquals("isFactorialPrime(3)", 1, IsFactorialPrime.isFactorialPrime(3));
		Assert.assertEquals("isFactorialPrime(7)", 1, IsFactorialPrime.isFactorialPrime(7));
		Assert.assertEquals("isFactorialPrime(8)", 0, IsFactorialPrime.isFactorialPrime(8));
		Assert.assertEquals("isFactorialPrime(11)", 0, IsFactorialPrime.isFactorialPrime(11));
		Assert.assertEquals("isFactorialPrime(721)", 0, IsFactorialPrime.isFactorialPrime(721));
		Assert.assertEquals("isFactorialPrime(121)", 0, IsFactorialPrime.isFactorialPrime(121));
	}
}
