package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsMinMaxDisjoint {

	@Test
	public void test() {

		int[] a1 = {18, -1, 3, 4, 0};
		int[] a2 = {9, 0, 5, 9};
		int[] a3 = {0, 5, 18, 0, 9};
		int[] a4 = {7, 7, 7, 7};
		int[] a5 = {};
		int[] a6 = {1, 2};
		int[] a7 = {5, 4, 1, 3, 2};
		
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a1)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a1));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a2)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a2));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a3)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a3));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a4)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a4));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a5)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a5));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a6)), 0, IsMinMaxDisjoint.isMinMaxDisjoint(a6));
		Assert.assertEquals(String.format("isMinMaxDisjoint(%s)",Arrays.toString(a7)), 1, IsMinMaxDisjoint.isMinMaxDisjoint(a7));
	}
}
