package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestEncodeArray {

	@Test
	public void test() {

		Assert.assertArrayEquals("encodeArray(0)", new int[] {1}, EncodeArray.encodeArray(0));
		Assert.assertArrayEquals("encodeArray(1)", new int[] {0, 1}, EncodeArray.encodeArray(1));
		Assert.assertArrayEquals("encodeArray(-1)", new int[] {-1, 0, 1}, EncodeArray.encodeArray(-1));
		Assert.assertArrayEquals("encodeArray(100001)", new int[] {0, 1, 1, 1, 1, 1, 0, 1}, EncodeArray.encodeArray(100001));
		Assert.assertArrayEquals("encodeArray(999)", new int[] {0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1}, EncodeArray.encodeArray(999));
	}
}
