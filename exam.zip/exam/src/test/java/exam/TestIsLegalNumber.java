package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsLegalNumber {
	
	@Test
	public void test() {
		
		Assert.assertEquals("isLegalNumber([3, 2, 1], 4)", 1, IsLegalNumber.isLegalNumber(new int[] {3, 2, 1}, 4));
		Assert.assertEquals("isLegalNumber([3, 7, 1], 6)", 0, IsLegalNumber.isLegalNumber(new int[] {3, 7, 1}, 6));
	}
}
