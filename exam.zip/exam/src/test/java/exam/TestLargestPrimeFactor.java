package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestLargestPrimeFactor {

	@Test
	public void test() {

		Assert.assertEquals("largestPrimeFactor(10)", 5, LargestPrimeFactor.largestPrimeFactor(10));
		Assert.assertEquals("largestPrimeFactor(6936)", 17, LargestPrimeFactor.largestPrimeFactor(6936));
		Assert.assertEquals("largestPrimeFactor(1)", 0, LargestPrimeFactor.largestPrimeFactor(1));
	}
}
