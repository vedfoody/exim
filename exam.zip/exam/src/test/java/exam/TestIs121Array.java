package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIs121Array {

	@Test
	public void test() {
	
		int[] a1 = {1, 2, 1};
		int[] a2 = {1, 1, 2, 2, 2, 1, 1};
		int[] a3 = {1, 1, 2, 2, 2, 1, 1, 1};
		int[] a4 = {1, 1, 2, 1, 2, 1, 1};
		int[] a5 = {1, 1, 1, 2, 2, 2, 1, 1, 1, 3};
		int[] a6 = {1, 1, 1, 1, 1, 1};
		int[] a7 = {2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1};
		
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a1)), 1, Is121Array.is121Array(a1));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a2)), 1, Is121Array.is121Array(a2));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a3)), 0, Is121Array.is121Array(a3));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a4)), 0, Is121Array.is121Array(a4));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a5)), 0, Is121Array.is121Array(a5));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a6)), 0, Is121Array.is121Array(a6));
		Assert.assertEquals(String.format("is121Array(%s)", Arrays.toString(a7)), 0, Is121Array.is121Array(a7));
	}	
}
