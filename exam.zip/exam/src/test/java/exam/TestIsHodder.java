package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsHodder {

	@Test
	public void test() {

		Assert.assertEquals("isHodder(3)", 1, IsHodder.isHodder(3));
		Assert.assertEquals("isHodder(7)", 1, IsHodder.isHodder(7));
		Assert.assertEquals("isHodder(31)", 1, IsHodder.isHodder(31));
		Assert.assertEquals("isHodder(127)", 1, IsHodder.isHodder(127));
		Assert.assertEquals("isHodder(251)", 0, IsHodder.isHodder(251));
		Assert.assertEquals("isHodder(13)", 0, IsHodder.isHodder(13));
		Assert.assertEquals("isHodder(53)", 0, IsHodder.isHodder(53));
	}
}
