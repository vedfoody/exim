package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestConvertToBase10 {
	
	@Test
	public void test() {
		
		Assert.assertEquals("convertToBase10([1, 0, 1, 1], 2)", 11, ConvertToBase10.convertToBase10(new int[] {1, 0, 1, 1}, 2));
		Assert.assertEquals("convertToBase10([1, 1, 2], 3)", 14, ConvertToBase10.convertToBase10(new int[] {1, 1, 2}, 3));
		Assert.assertEquals("convertToBase10([3, 2, 5], 8)", 213, ConvertToBase10.convertToBase10(new int[] {3, 2, 5}, 8));
		Assert.assertEquals("convertToBase10([3, 7, 1], 6)", 0, ConvertToBase10.convertToBase10(new int[] {3, 7, 1}, 6));
	}
}
