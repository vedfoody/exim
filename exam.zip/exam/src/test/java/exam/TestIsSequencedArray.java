package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsSequencedArray {

	@Test
	public void test() {

		Assert.assertEquals("isSequencedArray([1, 2, 3, 4, 5], 1, 5)", 1, IsSequencedArray.isSequencedArray(new int[] {1, 2, 3, 4, 5}, 1, 5));
		Assert.assertEquals("isSequencedArray([1, 3, 4, 2, 5], 1, 5)", 0, IsSequencedArray.isSequencedArray(new int[] {1, 3, 4, 2, 5}, 1, 5));
		Assert.assertEquals("isSequencedArray([-5, -5, -4, -4, -4, -3, -3, -2, -2, -2], -5, -2)", 1, IsSequencedArray.isSequencedArray(new int[] {-5, -5, -4, -4, -4, -3, -3, -2, -2, -2}, -5, -2));
		Assert.assertEquals("isSequencedArray([0, 1, 2, 3, 4, 5], 1, 5)", 0, IsSequencedArray.isSequencedArray(new int[] {0, 1, 2, 3, 4, 5}, 1, 5));
		Assert.assertEquals("isSequencedArray([1, 2, 3, 4], 1, 5)", 0, IsSequencedArray.isSequencedArray(new int[] {1, 2, 3, 4}, 1, 5));
		Assert.assertEquals("isSequencedArray([1, 2, 5], 1, 5)", 0, IsSequencedArray.isSequencedArray(new int[] {1, 2, 5}, 1, 5));
		Assert.assertEquals("isSequencedArray([5, 4, 3, 2, 1], 1,5 )", 0, IsSequencedArray.isSequencedArray(new int[] {5, 4, 3, 2, 1}, 1, 5));
	}	
}
