package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestCountRepresentations {

	@Test
	public void test() {

		Assert.assertEquals("countRepresentations(12)", 15, CountRepresentations.countRepresentations(12));
		Assert.assertEquals("countRepresentations(0)", 0, CountRepresentations.countRepresentations(0));
		Assert.assertEquals("countRepresentations(1)", 1, CountRepresentations.countRepresentations(1));
		Assert.assertEquals("countRepresentations(2)", 2, CountRepresentations.countRepresentations(2));
		Assert.assertEquals("countRepresentations(3)", 2, CountRepresentations.countRepresentations(3));
		Assert.assertEquals("countRepresentations(5)", 4, CountRepresentations.countRepresentations(5));
	}
}
