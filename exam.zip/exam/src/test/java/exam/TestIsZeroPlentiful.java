package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsZeroPlentiful {

	@Test
	public void test() {

		int[] a1 = {0, 0, 0, 0, 0};
		int[] a2 = {1, 2, 0, 0, 0, 0, 2, -18, 0, 0, 0, 0, 0, 12};
		int[] a3 = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0};
		int[] a4 = {1, 2, 3, 4};
		int[] a5 = {1, 0, 0, 0, 2, 0, 0, 0, 0};
		int[] a6 = {0};
		int[] a7 = {};
		
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a1)), 1, IsZeroPlentiful.isZeroPlentiful(a1));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a2)), 2, IsZeroPlentiful.isZeroPlentiful(a2));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a3)), 3, IsZeroPlentiful.isZeroPlentiful(a3));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a4)), 0, IsZeroPlentiful.isZeroPlentiful(a4));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a5)), 1, IsZeroPlentiful.isZeroPlentiful(a5));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a6)), 0, IsZeroPlentiful.isZeroPlentiful(a6));
		Assert.assertEquals(String.format("isZeroPlentiful(%s)",Arrays.toString(a7)), 0, IsZeroPlentiful.isZeroPlentiful(a7));
	}
}
