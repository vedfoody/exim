package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestCheckConcatenatedSum {

	@Test
	public void test() {	
		Assert.assertEquals("checkConcatenatedSum(198, 2)", 1, CheckConcatenatedSum.checkConcatenatedSum(198, 2));
		Assert.assertEquals("checkConcatenatedSum(198, 3)", 0, CheckConcatenatedSum.checkConcatenatedSum(198, 3));
		Assert.assertEquals("checkConcatenatedSum(2997, 3)", 1, CheckConcatenatedSum.checkConcatenatedSum(2997, 3));
		Assert.assertEquals("checkConcatenatedSum(2997, 2)", 0, CheckConcatenatedSum.checkConcatenatedSum(2997, 2));
		Assert.assertEquals("checkConcatenatedSum(13332, 4)", 1, CheckConcatenatedSum.checkConcatenatedSum(13332, 4));
		Assert.assertEquals("checkConcatenatedSum(9, 1)", 1, CheckConcatenatedSum.checkConcatenatedSum(9, 1));
	}	
}
