package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestFullnessQuotient {

	@Test
	public void test() {

		Assert.assertEquals("fullnessQuotient(94)", 6, FullnessQuotient.fullnessQuotient(94));
		Assert.assertEquals("fullnessQuotient(1)", 8, FullnessQuotient.fullnessQuotient(1));
		Assert.assertEquals("fullnessQuotient(9)", 5, FullnessQuotient.fullnessQuotient(9));
		Assert.assertEquals("fullnessQuotient(360)", 0, FullnessQuotient.fullnessQuotient(360));
		Assert.assertEquals("fullnessQuotient(-4)", -1, FullnessQuotient.fullnessQuotient(-4));
	}
}
