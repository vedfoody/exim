package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsNUnique {
	
	@Test
	public void test() {
		
		Assert.assertEquals("isNUnique([7, 3, 3, 2, 4], 6)", 0, IsNUnique.isNUnique(new int[] {7, 3, 3, 2, 4}, 6));
		Assert.assertEquals("isNUnique([7, 3, 3, 2, 4], 10)", 0, IsNUnique.isNUnique(new int[] {7, 3, 3, 2, 4}, 10));
		Assert.assertEquals("isNUnique([7, 3, 3, 2, 4], 11)", 1, IsNUnique.isNUnique(new int[] {7, 3, 3, 2, 4}, 11));
		Assert.assertEquals("isNUnique([7, 3, 3, 2, 4], 8)", 0, IsNUnique.isNUnique(new int[] {7, 3, 3, 2, 4}, 8));
		Assert.assertEquals("isNUnique([7, 3, 3, 2, 4], 4)", 0, IsNUnique.isNUnique(new int[] {7, 3, 3, 2, 4}, 4));
		Assert.assertEquals("isNUnique([1], 4)", 0, IsNUnique.isNUnique(new int[] {1}, 4));
		Assert.assertEquals("isNUnique([2, 7, 3, 4], 5)", 1, IsNUnique.isNUnique(new int[] {2, 7, 3, 4}, 5));
		Assert.assertEquals("isNUnique([2, 3, 3, 7], 5)", 0, IsNUnique.isNUnique(new int[] {2, 3, 3, 7}, 5));
	}
}
