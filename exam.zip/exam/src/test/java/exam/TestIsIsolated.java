package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsIsolated {

	@Test
	public void test() {

		Assert.assertEquals("isIsolated(2)", 1, IsIsolated.isIsolated(2));
		Assert.assertEquals("isIsolated(3)", 1, IsIsolated.isIsolated(3));
		Assert.assertEquals("isIsolated(8)", 1, IsIsolated.isIsolated(8));
		Assert.assertEquals("isIsolated(9)", 1, IsIsolated.isIsolated(9));
		Assert.assertEquals("isIsolated(14)", 1, IsIsolated.isIsolated(14));
		Assert.assertEquals("isIsolated(24)", 1, IsIsolated.isIsolated(24));
		Assert.assertEquals("isIsolated(28)", 1, IsIsolated.isIsolated(28));
		Assert.assertEquals("isIsolated(34)", 1, IsIsolated.isIsolated(34));
		Assert.assertEquals("isIsolated(58)", 1, IsIsolated.isIsolated(58));
		Assert.assertEquals("isIsolated(63)", 1, IsIsolated.isIsolated(63));
		Assert.assertEquals("isIsolated(163)", 1, IsIsolated.isIsolated(163));
		Assert.assertEquals("isIsolated(15)", 0, IsIsolated.isIsolated(15));
		Assert.assertEquals("isIsolated(68)", 0, IsIsolated.isIsolated(68));
		Assert.assertEquals("isIsolated(30)", 0, IsIsolated.isIsolated(30));
	}
}
