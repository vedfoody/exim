package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestEncodeNumber {

	@Test
	public void test() {

		Assert.assertArrayEquals("encodeNumber(2)", new int[] {2}, EncodeNumber.encodeNumber(2));
		Assert.assertArrayEquals("encodeNumber(6)", new int[] {2, 3}, EncodeNumber.encodeNumber(6));
		Assert.assertArrayEquals("encodeNumber(14)", new int[] {2, 7}, EncodeNumber.encodeNumber(14));
		Assert.assertArrayEquals("encodeNumber(24)", new int[] {2, 2, 2, 3}, EncodeNumber.encodeNumber(24));
		Assert.assertArrayEquals("encodeNumber(1200)", new int[] {2, 2, 2, 2, 3, 5, 5}, EncodeNumber.encodeNumber(1200));
		Assert.assertArrayEquals("encodeNumber(1)", null, EncodeNumber.encodeNumber(1));
		Assert.assertArrayEquals("encodeNumber(-18)", null, EncodeNumber.encodeNumber(-18));
	}
}
