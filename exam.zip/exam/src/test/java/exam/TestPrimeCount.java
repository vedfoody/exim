package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestPrimeCount {

	@Test
	public void test() {		
		Assert.assertEquals("primeCount(10, 30)", 6, PrimeCount.primeCount(10, 30));
		Assert.assertEquals("primeCount(11, 29)", 6, PrimeCount.primeCount(11, 29));
		Assert.assertEquals("primeCount(20, 22)", 0, PrimeCount.primeCount(20, 22));
		Assert.assertEquals("primeCount(1, 1)", 0, PrimeCount.primeCount(1, 1));
		Assert.assertEquals("primeCount(5, 5)", 1, PrimeCount.primeCount(5, 5));
		Assert.assertEquals("primeCount(6, 2)", 0, PrimeCount.primeCount(6, 2));
		Assert.assertEquals("primeCount(-10, 6)", 3, PrimeCount.primeCount(-10, 6));
	}
}
