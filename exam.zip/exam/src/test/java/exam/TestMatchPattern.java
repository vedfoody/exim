package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestMatchPattern {

	@Test
	public void test() {
		int[] a1 = {1, 1, 1, 1, 1};
		int[] p1 = {1};
		
		int[] a2 = {1};
		int[] p2 = {1};
		
		int[] a3 = {1, 1, 2, 2, 2, 2};
		int[] p3 = {1, 2};
		
		int[] a4 = {1, 2, 3};
		int[] p4 = {1, 2};
		
		int[] a5 = {1, 2};
		int[] p5 = {1, 2, 3};
		
		int[] a6 = {1, 1, 2, 2, 2, 2, 3};
		int[] p6 = {1, 3};
		
		int[] a7 = {1, 1, 1, 1};
		int[] p7 = {1, 2};
		
		int[] a8 = {1, 1, 1, 1, 2, 2, 3, 3};
		int[] p8 = {1, 2};
		
		int[] a9 = {1, 1, 10, 4, 4, 3};
		int[] p9 = {1, 4, 3};
		
		int[] a10 = {1, 1, 1, 2, 2, 1, 1, 3};
		int[] p10 = {1, 2, 1, 3};
		
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a1), Arrays.toString(p1)), 1, MatchPattern.matchPattern(a1, p1));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a2), Arrays.toString(p2)), 1, MatchPattern.matchPattern(a2, p2));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a3), Arrays.toString(p3)), 1, MatchPattern.matchPattern(a3, p3));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a4), Arrays.toString(p4)), 0, MatchPattern.matchPattern(a4, p4));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a5), Arrays.toString(p5)), 0, MatchPattern.matchPattern(a5, p5));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a6), Arrays.toString(p6)), 0, MatchPattern.matchPattern(a6, p6));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a7), Arrays.toString(p7)), 0, MatchPattern.matchPattern(a7, p7));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a8), Arrays.toString(p8)), 0, MatchPattern.matchPattern(a8, p8));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a9), Arrays.toString(p9)), 0, MatchPattern.matchPattern(a9, p9));
		Assert.assertEquals(String.format("matchPattern(%s, %s)", Arrays.toString(a10), Arrays.toString(p10)), 1, MatchPattern.matchPattern(a10, p10));
	}
}
