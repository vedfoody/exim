package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsSystematicallyIncreasing {

	@Test
	public void test() {
	
		int[] a1 = {1};
		int[] a2 = {1, 2, 1, 2, 3};
		int[] a3 = {1, 1, 3};
		int[] a4 = {1, 2, 1, 2, 1, 2};
		int[] a5 = {1, 2, 3, 1, 2, 1};
		int[] a6 = {1, 1, 2, 3};
		int[] a7 = {1, 1, 2};
		int[] a8 = {1, 1, 2, 1, 2, 3};
		int[] a9 = {1, 1, 2, 1, 2, 3, 1, 2, 3, 4};
		int[] a10 = {1, 1, 2, 1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5};
		int[] a11 = {1, 1, 2, 1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6};
		
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a1)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a1));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a2)), 0, IsSystematicallyIncreasing.isSystematicallyIncreasing(a2));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a3)), 0, IsSystematicallyIncreasing.isSystematicallyIncreasing(a3));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a4)), 0, IsSystematicallyIncreasing.isSystematicallyIncreasing(a4));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a5)), 0, IsSystematicallyIncreasing.isSystematicallyIncreasing(a5));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a6)), 0, IsSystematicallyIncreasing.isSystematicallyIncreasing(a6));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a7)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a7));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a8)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a8));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a9)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a9));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a10)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a10));
		Assert.assertEquals(String.format("isSystematicallyIncreasing(%s)", Arrays.toString(a11)), 1, IsSystematicallyIncreasing.isSystematicallyIncreasing(a11));
	}	
}
