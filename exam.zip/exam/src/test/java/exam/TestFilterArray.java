package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestFilterArray {

	@Test
	public void test() {
		Assert.assertArrayEquals("filterArray([9, -9], 0)",new int[] {}, FilterArray.filterArray(new int[] {9, -9}, 0));
		Assert.assertArrayEquals("filterArray([9, -9], 1)",new int[] {9}, FilterArray.filterArray(new int[] {9, -9}, 1));
		Assert.assertArrayEquals("filterArray([9, -9], 2)",new int[] {-9}, FilterArray.filterArray(new int[] {9, -9}, 2));
		Assert.assertArrayEquals("filterArray([9, -9], 3)",new int[] {9, -9}, FilterArray.filterArray(new int[] {9, -9}, 3));
		Assert.assertArrayEquals("filterArray([9, -9], 4)",null, FilterArray.filterArray(new int[] {9, -9}, 4));
		Assert.assertArrayEquals("filterArray([9, -9, 5], 3)",new int[] {9, -9}, FilterArray.filterArray(new int[] {9, -9, 5}, 3));
		Assert.assertArrayEquals("filterArray([0, 9, 12, 18, -6], 11)",new int[] {0, 9, 18}, FilterArray.filterArray(new int[] {0, 9, 12, 18, -6}, 11));
	}
}
