package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIs235Array {

	@Test
	public void test() {
	
		int[] a1 = {2, 3, 5, 7, 11};
		int[] a2 = {2, 3, 6, 7, 11};
		int[] a3 = {2, 3, 4, 5, 6, 7, 8, 9, 10};
		int[] a4 = {2, 4, 8, 16, 32};
		int[] a5 = {3, 9, 27, 7, 1, 1, 1, 1, 1};
		int[] a6 = {7, 11, 77, 49};
		int[] a7 = {2};
		int[] a8 = {};
		int[] a9 = {7, 2, 7, 2, 7, 2, 7, 2, 3, 7, 7};
		
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a1)), 1, Is235Array.is235Array(a1));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a2)), 0, Is235Array.is235Array(a2));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a3)), 0, Is235Array.is235Array(a3));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a4)), 1, Is235Array.is235Array(a4));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a5)), 1, Is235Array.is235Array(a5));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a6)), 1, Is235Array.is235Array(a6));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a7)), 1, Is235Array.is235Array(a7));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a8)), 1, Is235Array.is235Array(a8));
		Assert.assertEquals(String.format("is235Array(%s)", Arrays.toString(a9)), 1, Is235Array.is235Array(a9));
	}
}
