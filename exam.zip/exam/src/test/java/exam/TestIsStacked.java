package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsStacked {

	@Test
	public void test() {

		Assert.assertEquals("isStacked(1)", 1, IsStacked.isStacked(1));
		Assert.assertEquals("isStacked(3)", 1, IsStacked.isStacked(3));
		Assert.assertEquals("isStacked(6)", 1, IsStacked.isStacked(6));
		Assert.assertEquals("isStacked(10)", 1, IsStacked.isStacked(10));
		Assert.assertEquals("isStacked(15)", 1, IsStacked.isStacked(15));
		Assert.assertEquals("isStacked(7)", 0, IsStacked.isStacked(7));
		Assert.assertEquals("isStacked(16)", 0, IsStacked.isStacked(16));
	}
}
