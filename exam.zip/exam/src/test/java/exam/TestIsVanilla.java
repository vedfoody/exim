package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsVanilla {

	@Test
	public void test() {

		int[] a1 = {1};
		int[] a2 = {11, 22, 13, 34, 125};
		int[] a3 = {9, 999, 99999, -9999};
		int[] a4 = {};
		int[] a5 = {1, 1, 11, 1111, 1111111};
		int[] a6 = {11, 101, 1111, 11111};
		
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a1)), 1, IsVanilla.isVanilla(a1));
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a1)), 0, IsVanilla.isVanilla(a2));
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a1)), 1, IsVanilla.isVanilla(a3));
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a1)), 1, IsVanilla.isVanilla(a4));
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a5)), 1, IsVanilla.isVanilla(a5));
		Assert.assertEquals(String.format("isVanilla(%s)",Arrays.toString(a6)), 0, IsVanilla.isVanilla(a6));
	}
}
