package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestDoIntegerBasedRounding {

	@Test
	public void test() {
		int[] a1 = {1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a1, 2);
		Assert.assertArrayEquals("doIntegerBasedRounding([1, 2, 3, 4, 5], 2)", new int[] {2, 2, 4, 4, 6}, a1);
		
		int[] a2 = {1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a2, 3);
		Assert.assertArrayEquals("doIntegerBasedRounding([1, 2, 3, 4, 5], 3)", new int[] {0, 3, 3, 3, 6}, a2);
		
		int[] a3 = {1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a3, -3);
		Assert.assertArrayEquals("doIntegerBasedRounding([1, 2, 3, 4, 5], -3)", new int[] {1, 2, 3, 4, 5}, a3);
		
		int[] a4 = {-1, -2, -3, -4, -5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a4, 3);
		Assert.assertArrayEquals("doIntegerBasedRounding([-1, -2, -3, -4, -5], 3)", new int[] {-1, -2, -3, -4, -5}, a4);
		
		int[] a5 = {-18, 1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a5, 4);
		Assert.assertArrayEquals("doIntegerBasedRounding([-18, 1, 2, 3, 4, 5], 4)", new int[] {-18, 0, 4, 4, 4, 4}, a5);
		
		int[] a6 = {1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a6, 5);
		Assert.assertArrayEquals("doIntegerBasedRounding([1, 2, 3, 4, 5], 5)", new int[] {0, 0, 5, 5, 5}, a6);
		
		int[] a7 = {1, 2, 3, 4, 5};
		DoIntegerBasedRounding.doIntegerBasedRounding(a7, 100);
		Assert.assertArrayEquals("doIntegerBasedRounding([1, 2, 3, 4, 5], 100)", new int[] {0, 0, 0, 0, 0}, a7);
	}
	
}
