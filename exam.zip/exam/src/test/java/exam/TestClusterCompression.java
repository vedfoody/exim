package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestClusterCompression {

	@Test
	public void test() {

		Assert.assertArrayEquals("ClusterCompression([3, 3, 3, 4, 4, 3, 2, 2, 2, 2, 4])", new int[] {3, 4, 3, 2, 4}, ClusterCompression.clusterCompression(new int[] {3, 3, 3, 4, 4, 3, 2, 2, 2, 2, 4}));
		Assert.assertArrayEquals("ClusterCompression([0, 0, 0, 2, 0, 2, 0, 2, 0, 0])", new int[] {0, 2, 0, 2, 0, 2, 0}, ClusterCompression.clusterCompression(new int[] {0, 0, 0, 2, 0, 2, 0, 2, 0, 0}));
		Assert.assertArrayEquals("ClusterCompression([18])", new int[] {18}, ClusterCompression.clusterCompression(new int[] {18}));
		Assert.assertArrayEquals("ClusterCompression([])", new int[] {}, ClusterCompression.clusterCompression(new int[] {}));
		Assert.assertArrayEquals("ClusterCompression([-5, -5, -5, -5, -5])", new int[] {-5}, ClusterCompression.clusterCompression(new int[] {-5, -5, -5, -5, -5}));
		Assert.assertArrayEquals("ClusterCompression([1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1])", new int[] {1, 2, 1}, ClusterCompression.clusterCompression(new int[] {1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1}));
		Assert.assertArrayEquals("ClusterCompression([8, 8, 6, 6, -2, -2, -2])", new int[] {8, 6, -2}, ClusterCompression.clusterCompression(new int[] {8, 8, 6, 6, -2, -2, -2}));
	}
}
