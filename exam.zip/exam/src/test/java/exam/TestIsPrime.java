package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsPrime {

	@Test
	public void test() {

		Assert.assertEquals("isPrime(3)", 1, IsPrime.isPrime(3));
		Assert.assertEquals("isPrime(7)", 1, IsPrime.isPrime(7));
		Assert.assertEquals("isPrime(31)", 1, IsPrime.isPrime(31));
		Assert.assertEquals("isPrime(127)", 1, IsPrime.isPrime(127));
		Assert.assertEquals("isPrime(251)", 1, IsPrime.isPrime(251));
		Assert.assertEquals("isPrime(1)", 0, IsPrime.isPrime(1));
		Assert.assertEquals("isPrime(887)", 1, IsPrime.isPrime(887));
		Assert.assertEquals("isPrime(920)", 0, IsPrime.isPrime(920));
	}
}
