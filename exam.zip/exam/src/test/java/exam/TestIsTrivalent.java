package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsTrivalent {

	@Test
	public void test() {

		int[] a1 = {-1, 0, 1, 0, 0, 0};
		int[] a2 = {};
		int[] a3 = {-2147483647, -1, -1, -2147483648};
		int[] a4 = {22, 19, 10, 10, 19, 22, 22, 10};
		int[] a5 = {1, 2, 2, 2, 2, 2, 2};
		int[] a6 = {2, 2, 3, 3, 3, 3, 2, 41, 65};
		
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a1)), 1, IsTrivalent.isTrivalent(a1));
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a2)), 0, IsTrivalent.isTrivalent(a2));
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a3)), 1, IsTrivalent.isTrivalent(a3));
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a4)), 1, IsTrivalent.isTrivalent(a4));
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a5)), 0, IsTrivalent.isTrivalent(a5));
		Assert.assertEquals(String.format("isTrivalent(%s)",Arrays.toString(a6)), 0, IsTrivalent.isTrivalent(a6));
	}
}
