package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestAreAnagrams {

	@Test
	public void test() {
		char[] a1a = {'s', 'i', 't'};
		char[] a1b = {'i', 't', 's'};
		
		char[] a2a = {'s', 'i', 't'};
		char[] a2b = {'i', 'd', 's'};
		
		char[] a3a = {'b', 'i', 'g'};
		char[] a3b = {'b', 'i', 't'};
		
		char[] a4a = {'b', 'o', 'g'};
		char[] a4b = {'b', 'o', 'o'};
		
		char[] a5a = {};
		char[] a5b = {};
		
		char[] a6a = {'b', 'i', 'g'};
		char[] a6b = {'b', 'i', 'g'};
		
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a1a), Arrays.toString(a1b)), 1, AreAnagrams.areAnagrams(a1a, a1b));
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a2a), Arrays.toString(a2b)), 0, AreAnagrams.areAnagrams(a2a, a2b));
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a3a), Arrays.toString(a3b)), 0, AreAnagrams.areAnagrams(a3a, a3b));
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a4a), Arrays.toString(a4b)), 0, AreAnagrams.areAnagrams(a4a, a4b));
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a5a), Arrays.toString(a5b)), 1, AreAnagrams.areAnagrams(a5a, a5b));
		Assert.assertEquals(String.format("areAnagrams(%s, %s)", Arrays.toString(a6a), Arrays.toString(a6b)), 1, AreAnagrams.areAnagrams(a6a, a6b));
	}
	
}
