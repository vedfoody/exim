package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestMatches {

	@Test
	public void test() {
		int[] a1 = {1, 2, 3, -5, -5, 2, 3, 18};
		int[] p1 = {3, -2, 3};
		int[] p2 = {2, 1, -1, -1, 2, 1};
		int[] p3 = {1, 2, -1, -1, 1, 2};
		int[] p4 = {2, 1, -2, 3};
		int[] p5 = {1, 1, 1, -1, -1, 1, 1, 1};
		int[] p6 = {4, -1, 3};
		int[] p7 = {2, -3, 3};
		int[] p8 = {8};
		
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p1)), 1, Matches.matches(a1, p1));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p2)), 1, Matches.matches(a1, p2));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p3)), 1, Matches.matches(a1, p3));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p4)), 1, Matches.matches(a1, p4));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p5)), 1, Matches.matches(a1, p5));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p6)), 0, Matches.matches(a1, p6));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p7)), 0, Matches.matches(a1, p7));
		Assert.assertEquals(String.format("matches(%s, %s)", Arrays.toString(a1), Arrays.toString(p8)), 0, Matches.matches(a1, p8));
	}
}
