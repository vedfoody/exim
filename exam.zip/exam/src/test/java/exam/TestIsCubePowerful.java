package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsCubePowerful {

	@Test
	public void test() {

		Assert.assertEquals("isCubePowerful(153)", 1, IsCubePowerful.isCubePowerful(153));
		Assert.assertEquals("isCubePowerful(370)", 1, IsCubePowerful.isCubePowerful(370));
		Assert.assertEquals("isCubePowerful(371)", 1, IsCubePowerful.isCubePowerful(371));
		Assert.assertEquals("isCubePowerful(407)", 1, IsCubePowerful.isCubePowerful(407));
		Assert.assertEquals("isCubePowerful(87)", 0, IsCubePowerful.isCubePowerful(87));
		Assert.assertEquals("isCubePowerful(0)", 0, IsCubePowerful.isCubePowerful(0));
		Assert.assertEquals("isCubePowerful(-81)", 0, IsCubePowerful.isCubePowerful(-81));
	}
}
