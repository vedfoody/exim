package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsOnionArray {

	@Test
	public void test() {
	
		int[] a1 = {1, 2, 19, 4, 5};
		int[] a2 = {1, 2, 3, 4, 15};
		int[] a3 = {1, 3, 9, 8};
		int[] a4 = {2};
		int[] a5 = {};
		int[] a6 = {-2, 5, 0, 5, 12};
		
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a1)), 1, IsOnionArray.isOnionArray(a1));
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a2)), 0, IsOnionArray.isOnionArray(a2));
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a3)), 0, IsOnionArray.isOnionArray(a3));
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a4)), 1, IsOnionArray.isOnionArray(a4));
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a5)), 1, IsOnionArray.isOnionArray(a5));
		Assert.assertEquals(String.format("IsOnionArray(%s)", Arrays.toString(a6)), 1, IsOnionArray.isOnionArray(a6));
	}	
}
