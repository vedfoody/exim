package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsMartian {

	@Test
	public void test() {
		int[] a1 = {1, 3};
		int[] a2 = {1, 2, 1, 2, 1, 2, 1, 2, 1};
		int[] a3 = {1, 3, 2};
		int[] a4 = {1, 3, 2, 2, 1, 5, 1, 5};
		int[] a5 = {1, 2, -18, -18, 1, 2};
		int[] a6 = {};
		int[] a7 = {1};
		int[] a8 = {2};
		
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a1)), 1, IsMartian.isMartian(a1));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a2)), 1, IsMartian.isMartian(a2));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a3)), 0, IsMartian.isMartian(a3));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a4)), 0, IsMartian.isMartian(a4));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a5)), 0, IsMartian.isMartian(a5));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a6)), 0, IsMartian.isMartian(a6));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a7)), 1, IsMartian.isMartian(a7));
		Assert.assertEquals(String.format("isMartian(%s)", Arrays.toString(a8)), 0, IsMartian.isMartian(a8));
	}
}
