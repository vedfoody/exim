package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsDigitIncreasing {

	@Test
	public void test() {	
		Assert.assertEquals("isDigitIncreasing(7)", 1, IsDigitIncreasing.isDigitIncreasing(7));
		Assert.assertEquals("isDigitIncreasing(36)", 1, IsDigitIncreasing.isDigitIncreasing(36));
		Assert.assertEquals("isDigitIncreasing(984)", 1, IsDigitIncreasing.isDigitIncreasing(984));
		Assert.assertEquals("isDigitIncreasing(7404)", 1, IsDigitIncreasing.isDigitIncreasing(7404));
	}	
}
