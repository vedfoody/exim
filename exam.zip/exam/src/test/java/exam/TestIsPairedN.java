package exam;

import org.junit.Assert;

import java.util.Arrays;

import org.junit.Test;

public class TestIsPairedN {

	@Test
	public void test() {
		int[] a1 = {1, 4, 1, 4, 5, 6};
		int n1 = 5;
		
		int[] a2 = {1, 4, 1, 4, 5, 6};
		int n2 = 6;
		
		int[] a3 = {0, 1, 2, 3, 4, 5, 6, 7, 8};
		int n3 = 6;
		
		int[] a4 = {1, 4, 1};
		int n4 = 5;
		
		int[] a5 = {8, 8, 8, 8, 7, 7, 7};
		int n5 = 15;
		
		int[] a6 = {8, -8, 8, 8, 7, 7, -7};
		int n6 = -15;
		
		int[] a7 = {3};
		int n7 = 3;
		
		int[] a8 = {};
		int n8 = 0;
		
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a1), n1), 1, IsPairedN.isPairedN(a1, n1));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a2), n2), 1, IsPairedN.isPairedN(a2, n2));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a3), n3), 1, IsPairedN.isPairedN(a3, n3));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a4), n4), 0, IsPairedN.isPairedN(a4, n4));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a5), n5), 0, IsPairedN.isPairedN(a5, n5));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a6), n6), 0, IsPairedN.isPairedN(a6, n6));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a7), n7), 0, IsPairedN.isPairedN(a7, n7));
		Assert.assertEquals(String.format("isPairedN(%s,%d)", Arrays.toString(a8), n8), 0, IsPairedN.isPairedN(a8, n8));
	}
}
