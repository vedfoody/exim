package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestDecodeArray {

	@Test
	public void test() {

		int[] a1 = {1};
		int[] a2 = {0, 1};
		int[] a3 = {-1, 0, 1};
		int[] a4 = {0, 1, 1, 1, 1, 1, 0, 1};
		int[] a5 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1};
		
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a1)), 0, DecodeArray.decodeArray(a1));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a2)), 1, DecodeArray.decodeArray(a2));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a3)), -1, DecodeArray.decodeArray(a3));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a4)), 100001, DecodeArray.decodeArray(a4));
		Assert.assertEquals(String.format("decodeArray(%s)",Arrays.toString(a5)), 999, DecodeArray.decodeArray(a5));
	}
}
