package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestGetExponent {

	@Test
	public void test() {
		
		Assert.assertEquals("getExponent(27, 3)", 3, GetExponent.getExponent(27, 3));
		Assert.assertEquals("getExponent(28, 3)", 0, GetExponent.getExponent(28, 3));
		Assert.assertEquals("getExponent(280, 7)", 1, GetExponent.getExponent(280, 7));
		Assert.assertEquals("getExponent(-250, 5)", 3, GetExponent.getExponent(-250, 5));
		Assert.assertEquals("getExponent(18, 1)", -1, GetExponent.getExponent(18, 1));
		Assert.assertEquals("getExponent(128, 4)", 3, GetExponent.getExponent(128, 4));
	}
}
