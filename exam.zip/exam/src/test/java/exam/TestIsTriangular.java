package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsTriangular {

	@Test
	public void test() {

		Assert.assertEquals("isTriangular(1)", 1, IsTriangular.isTriangular(1));
		Assert.assertEquals("isTriangular(3)", 1, IsTriangular.isTriangular(3));
		Assert.assertEquals("isTriangular(6)", 1, IsTriangular.isTriangular(6));
		Assert.assertEquals("isTriangular(10)", 1, IsTriangular.isTriangular(10));
		Assert.assertEquals("isTriangular(9)", 0, IsTriangular.isTriangular(9));
		Assert.assertEquals("isTriangular(8)", 0, IsTriangular.isTriangular(8));
	}
}
