package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestClosestFibonacci {

	@Test
	public void test() {
		// closestFibonacci(int n) returns the largest Fibonacci number that is less than or equal to its argument
		Assert.assertEquals("closestFibonacci(13)", 13, ClosestFibonacci.closestFibonacci(13)); 
		Assert.assertEquals("closestFibonacci(33)", 21, ClosestFibonacci.closestFibonacci(33));
		Assert.assertEquals("closestFibonacci(34)", 34, ClosestFibonacci.closestFibonacci(34));
	}
	
}
