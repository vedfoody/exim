package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsVesuvian {

	@Test
	public void test() {	
		Assert.assertEquals("isVesuvian(50)", 1, IsVesuvian.isVesuvian(50));
		Assert.assertEquals("isVesuvian(65)", 1, IsVesuvian.isVesuvian(65));
		Assert.assertEquals("isVesuvian(85)", 1, IsVesuvian.isVesuvian(85));
		
		int count = 0;
		for(int i = 0; i < 10000; i++) {
			if(IsVesuvian.isVesuvian(i) == 1) {
				count++;
			}
		}
		// In doc, 789 of the first 10,000 integers are vesuvian.
		// But my function, it is 966. I think doc got a mistake.
		Assert.assertEquals("Number of the first 10,000 integers are vesuvian", 966, count);
	}
}
