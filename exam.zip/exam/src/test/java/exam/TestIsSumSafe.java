package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsSumSafe {

	@Test
	public void test() {

		int[] a1 = {5, -5, 0};
		int[] a2 = {5, -2, 1};

		Assert.assertEquals(String.format("isSumSafe(%s)",Arrays.toString(a1)), 0, IsSumSafe.isSumSafe(a1));
		Assert.assertEquals(String.format("isSumSafe(%s)",Arrays.toString(a2)), 1, IsSumSafe.isSumSafe(a2));
	}
}
