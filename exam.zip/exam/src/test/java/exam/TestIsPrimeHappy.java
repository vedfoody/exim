package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsPrimeHappy {

	@Test
	public void test() {

		Assert.assertEquals("isPrimeHappy(5)", 1, IsPrimeHappy.isPrimeHappy(5));
		Assert.assertEquals("isPrimeHappy(25)", 1, IsPrimeHappy.isPrimeHappy(25));
		Assert.assertEquals("isPrimeHappy(32)", 1, IsPrimeHappy.isPrimeHappy(32));
		Assert.assertEquals("isPrimeHappy(8)", 0, IsPrimeHappy.isPrimeHappy(8));
		Assert.assertEquals("isPrimeHappy(2)", 0, IsPrimeHappy.isPrimeHappy(2));
	}
}
