package exam;

import org.junit.Assert;
import org.junit.Test;

public class TestIsDivisible {

	@Test
	public void test() {

		Assert.assertEquals("isDivisible([3, 3, 6, 36], 3)", 1, IsDivisible.isDivisible(new int[] {3, 3, 6, 36}, 3));
		Assert.assertEquals("isDivisible([4], 2)", 1, IsDivisible.isDivisible(new int[] {4}, 2));
		Assert.assertEquals("isDivisible([3, 4, 3, 6, 36], 3)", 0, IsDivisible.isDivisible(new int[] {3, 4, 3, 6, 36}, 3));
		Assert.assertEquals("isDivisible([6, 12, 24, 36], 12)", 0, IsDivisible.isDivisible(new int[] {6, 12, 24, 36}, 12));
		Assert.assertEquals("isDivisible([], 4)", 1, IsDivisible.isDivisible(new int[] {}, 4));
	}
}
