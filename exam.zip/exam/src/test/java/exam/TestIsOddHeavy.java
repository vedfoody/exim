package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsOddHeavy {

	@Test
	public void test() {

		int[] a1 = {1};
		int[] a2 = {2};
		int[] a3 = {1, 1, 1, 1, 1, 1};
		int[] a4 = {2, 4, 6, 8, 11};
		int[] a5 = {-2, -4, -6, -8, -11};
		
		Assert.assertEquals(String.format("isOddHeavy(%s)",Arrays.toString(a1)), 1, IsOddHeavy.isOddHeavy(a1));
		Assert.assertEquals(String.format("isOddHeavy(%s)",Arrays.toString(a2)), 0, IsOddHeavy.isOddHeavy(a2));
		Assert.assertEquals(String.format("isOddHeavy(%s)",Arrays.toString(a3)), 1, IsOddHeavy.isOddHeavy(a3));
		Assert.assertEquals(String.format("isOddHeavy(%s)",Arrays.toString(a4)), 1, IsOddHeavy.isOddHeavy(a4));
		Assert.assertEquals(String.format("isOddHeavy(%s)",Arrays.toString(a5)), 0, IsOddHeavy.isOddHeavy(a5));
	}
}
