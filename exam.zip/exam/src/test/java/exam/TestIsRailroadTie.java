package exam;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestIsRailroadTie {

	@Test
	public void test() {

		int[] a1 = {1, 2};
		int[] a2 = {1, 2, 0, 1, 2, 0, 1, 2};
		int[] a3 = {3, 3, 0, 3, 3, 0, 3, 3, 0, 3, 3};
		int[] a4 = {0, 0, 0, 0};
		int[] a5 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int[] a6 = {1, 3, 0, 3, 5, 0};
		
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a2)), 1, IsRailroadTie.isRailroadTie(a2));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a1)), 1, IsRailroadTie.isRailroadTie(a1));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a2)), 1, IsRailroadTie.isRailroadTie(a2));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a3)), 1, IsRailroadTie.isRailroadTie(a3));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a4)), 0, IsRailroadTie.isRailroadTie(a4));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a5)), 0, IsRailroadTie.isRailroadTie(a5));
		Assert.assertEquals(String.format("isRailroadTie(%s)", Arrays.toString(a6)), 0, IsRailroadTie.isRailroadTie(a6));
	}
}
